!!! Das Programm benötigt JavaFX Bibliothek

Vor der Ausführung mit der Start.vbs bitte in der preStart.bat Datei den richtigen Pfad zu JavaFX Module eingeben.